<footer>
	<p>Copyright &copy; <?php echo date("Y"); echo " "; bloginfo('name'); ?></p>
</footer>
</div> <!-- end outerWrapper -->
</body>
</html>