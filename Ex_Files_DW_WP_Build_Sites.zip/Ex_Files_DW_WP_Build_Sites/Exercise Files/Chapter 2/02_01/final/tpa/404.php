<?php get_header(); ?>
<div id="contentWrap">
    <div id="content">
    	<h2>Sorry, but I couldn't find that page.</h2>
    </div> <!-- end contentWrap -->
<?php get_sidebar(); ?>
</div> <!-- end content -->
<?php get_footer(); ?>
