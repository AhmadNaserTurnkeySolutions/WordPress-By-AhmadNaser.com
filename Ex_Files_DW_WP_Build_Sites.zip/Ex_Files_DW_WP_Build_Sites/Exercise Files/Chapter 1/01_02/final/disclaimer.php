<?php
	require('wp-blog-header.php');
	get_header();
?>

<h2>Disclaimer</h2>
<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis id tellus  at tellus aliquam eleifend. Sed mauris lectus, viverra ac tristique sit  amet, sollicitudin non odio. Maecenas a nulla at libero feugiat  pellentesque at sed nibh. Praesent eget turpis non orci luctus lobortis  quis vitae nisl. Praesent massa eros, cursus ut dapibus in, aliquet non  velit. Duis sapien augue, pharetra ac suscipit aliquam, pulvinar ut  lacus. In hac habitasse platea dictumst. Nulla et sapien quis magna  fringilla varius. Integer hendrerit consequat arcu, nec scelerisque est  tincidunt eu. Donec ac erat consequat mauris condimentum mattis.  Pellentesque habitant morbi tristique senectus et netus et malesuada  fames ac turpis egestas. Proin ut lacus ipsum. Maecenas varius imperdiet  elementum. </p>
<p> Proin vitae lacinia urna. Vestibulum ante ipsum primis in faucibus orci  luctus et ultrices posuere cubilia Curae; Cras cursus malesuada elit,  convallis cursus ligula dignissim in. Maecenas nibh metus, dignissim  eget condimentum in, pharetra quis dolor. Vivamus sit amet neque massa,  id rhoncus tortor. Ut consequat tellus ultricies nunc placerat vel  fringilla est pellentesque. Nulla fringilla gravida nulla, ac dignissim  turpis commodo et. Donec vehicula, lectus nec accumsan semper, odio  dolor rutrum turpis, eget varius orci ipsum vel sem. Sed non est diam,  at suscipit turpis. Nullam eget libero vel purus aliquet hendrerit id ac  risus. </p>

<?php get_footer(); ?>