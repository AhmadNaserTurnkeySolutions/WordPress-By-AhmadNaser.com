<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<style type="text/css">
#planet th {
	text-align: right;
	vertical-align: top;
	padding-right: 5px;
}
</style>
</head>

<body>
<h1>Info on a planet</h1>
<table width="500" border="0" id="planet">
  <tr>
    <th scope="row">Planet</th>
    <td>placeholder</td>
  </tr>
  <tr>
    <th scope="row">Distance from Sun</th>
    <td>placeholder</td>
  </tr>
  <tr>
    <th scope="row">Moons</th>
    <td>placeholder</td>
  </tr>
  <tr>
    <th scope="row">Length of Orbit <br />
    (in Earth Years)</th>
    <td valign="top">placeholder</td>
  </tr>
</table>
</body>
</html>
